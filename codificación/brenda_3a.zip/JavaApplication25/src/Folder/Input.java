/*
 * Class Input
 * @author Brenda
 *
 * Copyright (c) 2022-2023 UV. All Rights Reserved.
 */

import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;

/**
 * Clase para leer un documento de entrada de datos.
 *
 * @version 1.0 15 Junio 2022
 * @author Brenda Cueto
 * */

public class Input {

    /**
     * Default constructor
     */
    public Input() {
    }

    private String data;
    private BufferedReader br = null;

    /**
     * @param inFile 
     * @return
     */
    public String readData(String inFile) {
        try 
        {
            br = new BufferedReader(new FileReader(inFile));
            StringBuilder sb = new StringBuilder();
            String line;
            // = br.readLine();
            while ( (line = br.readLine()) != null ) 
                {
                    sb.append(line);
                    sb.append(",");
                }
            data = sb.toString();
        } 
        catch (IOException e) 
            {
                System.out.println("error : " + e);
                e.printStackTrace();
            }

        return data;
    }
}
