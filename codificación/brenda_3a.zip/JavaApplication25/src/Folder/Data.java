
/*
 * Class Data
 * @author Brenda Cueto
 *
 * Copyright (c) 2022-2023 UV. All Rights Reserved.
 */

/**
 * Clase para guardar la información en un array.
 *
 * @version 1.0 15 Junio 2022
 * @author Brenda Cueto
 */

public class Data {

    /**
     * Default constructor
     */
    public Data() {
    }

    /**
     * @param data 
     * @return
     */
    public String[] saveData(String data) {
        String[] arrData = data.split(",");
        return arrData;
    }

}
